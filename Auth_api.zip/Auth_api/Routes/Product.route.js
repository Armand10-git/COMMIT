const express = require('express')
const router = express.Router()

router.get('/', (req, res, next) => {
    res.send('getter product...');
});

router.post('/', (req, res, next) => {
    res.send('Product created...');
});

router.get('/:id',(req, res, next) => {
    res.send('Get product by id...');
});

router.patch('/:id',(req, res, next) => {
    res.send('update product by id...');
});

router.delete('/:id',(req, res, next) => {
    res.send('deleted product by id...');
});

module.exports = router;