// const mongoose = require('mongoose')
// const Schema = mongoose.Schema

// const ProductSchema = new Schema({
//     name: {
//         type: String,
//         require: true,
//         unique: true
//     },
//     description: {
//         type: String,
//         require: true,
//     }
//     price: {
//         type: String,
//         require: true,
//     }
// })

// ProductSchema.pre('save', async function(next) {
//     try {
//         const salt = await bcrypt.genSalt(10)
//         const hashedPassword = await bcrypt.hash(this.password, salt)
//         this.password = hashedPassword
//         next()
//     } catch (error) {
//         next(error)
//     }
// })

// const User = mongoose.model('product', ProductSchema)
// module.exports = User
